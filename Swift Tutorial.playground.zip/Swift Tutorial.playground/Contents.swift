//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//Simple Values

var myVariable = 42

myVariable = 50

let myConstant = 42



let implicitInteger = 70

let implicitDouble = 70.0

let explicitDouble:Double = 70




let implicitFloat = 64.1

let implicitFloat2 = 63.1

let explicitFloat:Float = 4.1


// what is the different 63.1 and 64.1 ??
//Why output is changing ??


let label = "The width is "
let width = 94
let widthLabel = label + String(width)

// lets try removing the conversion to String from the last line.

let apple = 3
let orange = 5

let appleSummary = "I have \(apple) apples"
let fruitSummary = "I have \(apple + orange) pieces of fruit"





var shoppingList = ["catfish","water","tulips"]
var occupations = ["Malcom": "Captain","Kaylee":"Mechanic"]
shoppingList[1] = "bottle of water"


print(shoppingList[0])

let emptyArray = [String]()

print(shoppingList)
print(fruitSummary)
print(shoppingList[2])
print(occupations)

//Control Flow


let individualScores = [75, 43, 103, 87, 12]

var teamScore = 0

for score in individualScores{
    if score > 50
    {teamScore += 3 }
    else{
    
    teamScore  += 1
    }

}

print(teamScore)


