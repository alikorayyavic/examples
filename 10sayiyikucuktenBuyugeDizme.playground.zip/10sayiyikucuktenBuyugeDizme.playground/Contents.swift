//: Playground - noun: a place where people can play

import UIKit




var emptyArray = [UInt32]()// create a empty array

var a:Int

for i in 0...9{
    
    var randomNumber:UInt32 = arc4random_uniform(100)
    var a = randomNumber
emptyArray.append(a)
}

print(emptyArray)


var minValue = emptyArray[0]

//for i in 0...(emptyArray.count - 1) {
//    for i in 0...(emptyArray.count - 1) {
//        
//        if minValue > emptyArray[i] {
//            minValue = emptyArray[i]
//        }
//    }
//print(minValue)}

for i in 0...(emptyArray.count-1){
    for j in 0...(emptyArray.count-1){
        
        if (emptyArray[i] > emptyArray[j]){
         
            var shit = emptyArray[i]
            emptyArray[i] = emptyArray[j]
            emptyArray[j] = shit
        
        }
    }
   
}
print(emptyArray.reverse())